# Secure File-sharing System

## Description
The goal is to create a secure file-sharing system between two types of users: Operation Users (Ops Users) and Client Users. This system will be implemented using REST APIs to perform various actions. Below is an overview of the actions that each type of user can perform.

### Ops User (Operation User):

- #### Login:
    Ops Users will be able to log in securely using their credentials.

- #### Upload File:
    Ops Users are allowed to upload files, but only files with specific types (pptx, docx, xlsx) are allowed.
    The system should enforce that only these file types are accepted during the upload process.

### Client User:

- #### Sign Up:
    Client Users can sign up for the system, and the system should return an encrypted URL.
    This URL may be used for further verification or to complete the registration process.

- #### Login:
     Client Users will be able to log in securely using their credentials.

- #### Download File:
    Client Users can download files that have been uploaded by Ops Users.
    The system should ensure secure and authorized access to the files.

- #### List all uploaded files:
    Client Users can view a list of all files that have been uploaded by Ops Users.
    This list may include information such as file names, types, and upload dates.
## Getting Started

### Dependencies

* Prerequisites
  * Docker
  * Python 
  
* Libraries 
  * Fastapi 
  * Boto3
  * Sqlite3

### Installing

* Clone Repository
```commandline
git clone git@github.com:varunbainsla/Secure_File_sharing_System.git
```

### Setup


* Install required libraries
```commandline
pip install -r requirements.txt
```
* Setup Docker Container
```
docker-compose up -d
```

* Run ```main.py``` 


#   A - s e c u r e - f i l e - s h a r i n g - s y s t e m - b e t w e e n - t w o - d i f f e r e n t - t y p e s - o f - u s e r s .  
 